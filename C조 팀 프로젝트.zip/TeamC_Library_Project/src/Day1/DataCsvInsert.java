package Day1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class DataCsvInsert {
	
	public void BookInsert() throws IOException {
		File file = new File("C:\\dev\\workspace\\TeamC_Library_Project\\book.csv");
		// ↓↓↓
		boolean flag = file.exists();
		if(flag) {
		FileReader fr = new FileReader(file);
		// ↓↓↓
		BufferedReader br = new BufferedReader(fr);
		// ↓↓↓
		String line = null;
		while((line=br.readLine()) != null) {
			 System.out.println(line);
		}
		br.close();
		fr.close();
		} else {
		System.out.println("file not exist");
		}
	}
	
	public void StudentInsert() throws IOException {
		File file = new File("C:\\dev\\workspace\\TeamC_Library_Project\\student.csv");
		// ↓↓↓
		boolean flag = file.exists();
		if(flag) {
		FileReader fr = new FileReader(file);
		// ↓↓↓
		BufferedReader br = new BufferedReader(fr);
		// ↓↓↓
		String line = null;
		while((line=br.readLine()) != null) {
			 System.out.println(line);
		}
		br.close();
		fr.close();
		} else {
		System.out.println("file not exist");
		}
	}
}
