package Day1;

public class ReservationBook {
	
	StudentVO student;
	BookVO book;
	
	public ReservationBook(StudentVO student, BookVO book) {}
	
	// 학생의 예약중인 도서 권 수 확인 (최대 3권)
	public boolean checkReservationableStu() {
		boolean flag = false;
		
		return flag;
	}
	
	// 해당 도서의 예약 인원 확인 (최대 2명)
	public boolean checkReservationableBook() {
		boolean flag = false;
		
		return flag;
	}
	
	// 도서 예약 확인
	public boolean reservationConfirm() {
		boolean flag = false;
		
		return flag;
	}

	// 도서 예약 취소
	public void reservationCancell() {
		
	}
}
