package Day1;

public class BorrowBook {
	
	StudentVO student;
	BookVO book;
	
	public BorrowBook(StudentVO student, BookVO book) {}
	
	// 학생이 대출정지상태인지 확인
	public boolean checkSuspention() {
		boolean flag = false;
		
		return flag;
	}
	
	// 학생의 미반납도서 중 연체도서가 있는지
	public boolean checkUnreturnBook() {
		boolean flag = false;
		
		return flag;
	}
	
	// 학생이 빌린 도서가 5권 인지? (최대 대여 도서 수량)
	public boolean checkBrrowable() {
		boolean flag = false;
		
		return flag;
	}
	
	// 학생이 빌리려는 도서가 도서관에 있는지? 
	public boolean checkHaveBook() {
		boolean flag = false;
		
		return flag;
	}
	
	// 도서 대여 실행
	public boolean borrowConfirm() {
		boolean flag = false;
		
		return flag;
	}
	
	// 도서 대여 취소
	public void borrowCancell() {
		 
	}
	

}
