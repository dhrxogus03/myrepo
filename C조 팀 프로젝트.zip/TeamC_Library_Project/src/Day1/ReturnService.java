package Day1;

import java.sql.SQLException;
import java.util.ArrayList;

public class ReturnService {
	public void returnBook() throws SQLException {
//		Calendar cal = Calendar.getInstance();
//		Date dt = new Date();
//		BorrowVO bvo = new BorrowVO();
//		StudentVO svo = new StudentVO();
//		int borrowDate = bvo.borrowDate();
//		int reserveDate = bvo.reserveDate();
//		int returnDate = dt.getDate();
//		int stopDate = svo.stopDate();
//		if(bvo.reserveDate.getMonth()!=dt.getMonth()) {
//			stopDate += cal.getActualMaximum(Calendar.DAY_OF_MONTH);
//			if (returnDate>reserveDate) {
//				if (stopDate>returnDate) {
//					stopDate+=(returnDate-reserveDate);
//				} else {
//					stopDate = returnDate+(returnDate-reserveDate);
//				}
//			}
//		}
		LibraryDAO dao = new LibraryDAO();
		
		ArrayList<BookVO> list = dao.selectBook();
		
		for(BookVO vo : list) {
			System.out.println(vo.getBook_name());
		}
		
		System.out.println("반납");
	}
}