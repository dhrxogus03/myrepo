package Day1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class LibraryDAO {
	//대출장부 추가
//	public boolean insertRentalBook(ArrayList<LoanVO> list) {
//		boolean flag = false;
//		Connection con = ConnectionManager.getConnection();
//		String sql = "insert into loanTBL(loan_date,exp_return_date,std_no,book_no,return_date,retrun_yn) values (?,?,?,?,?,?)";
//		PreparedStatement pstmt = con.prepareStatement(sql);
//		
//		int affectedCount = 0;
//		for(LoanVO vo : list) {
//			pstmt.setString(2, vo.getReturn_date());//대출일
//			pstmt.setString(3, vo.getExp_return_date());//반납예정일
//			pstmt.setInt(4, vo.getStu_no());//학번
//			pstmt.setInt(5, vo.get());//분류번호
//			pstmt.setString(6, vo.get());//반납일
//			pstmt.setString(7, vo.get());//반납여부
//			affectedCount = pstmt.executeUpdate();
//		}
//		if (affectedCount>0) {
//			flag = true;
//		}
//		ConnectionManager.closeConnection(null, pstmt, con);
//		System.out.println("대출장부 추가");
//		return flag;
//	}
//	//예약장부 추가
//	public boolean insertReserveBook(ArrayList<ReservationVO> list) {
//		boolean flag = false;
//		Connection con = ConnectionManager.getConnection();
//		String sql = "insert into rsvsTBL(rsvs_date,std_no,book_no) values (?,?,?)";
//		PreparedStatement pstmt = con.prepareStatement(sql);
//		int affectedCount = 0;
//		for(LoanVO vo : list) {
//			pstmt.setString(2, vo.get());//예약일
//			pstmt.setString(3, vo.get());//학번
//			pstmt.setInt(4, vo.get());//분류번호
//			affectedCount = pstmt.executeUpdate();
//		}
//		if (affectedCount>0) {
//			flag = true;
//		}
//		ConnectionManager.closeConnection(null, pstmt, con);
//		System.out.println("예약장부 추가");
//		return flag;
//	}
	//대출장부 조회
	public ArrayList<LoanVO> selectRentalBook(String stdNo) throws SQLException {
		ArrayList<LoanVO> list = new ArrayList<LoanVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from loanTBL where std_no=?";//학번
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, stdNo);
		
		ResultSet rs = pstmt.executeQuery();
		LoanVO vo = null;
		while (rs.next()) {
			vo = new LoanVO(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),
					rs.getInt(5),rs.getString(6),rs.getString(7));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}
//	//예약장부 조회
//	public ArrayList<ReservationVO> selectReserveBook(String rsvsDate) {
//		ArrayList<ReservationVO> list = new ArrayList<ReservationVO>();
//		Connection con = ConnectionManager.getConnection();
//		String sql = "select * from rsvsTBL where rsvs_date=?";//예약일
//		PreparedStatement pstmt = con.prepareStatement(sql);
//		pstmt.setString(1, rsvsDate);
//		
//		ResultSet rs = pstmt.executeQuery();
//		LibraryVO vo = null;
//		while (rs.next()) {
//			vo = new ReservationVO(rs.getInt(1),rs.getString(2),rs.getInt(3),
//					rs.getInt(4),rs.getInt(5));
//			list.add(vo);
//		}
//		ConnectionManager.closeConnection(rs, pstmt, con);
//		return list;
//	}
	//학생정보 조회
	public ArrayList<StudentVO> selectStudent(String name) throws SQLException {//학생이름
		ArrayList<StudentVO> list = new ArrayList<StudentVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from studentTBL where std_name=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, name);
		ResultSet rs = pstmt.executeQuery();
		StudentVO vo = null;
		while (rs.next()) {
			vo = new StudentVO(rs.getInt(1), rs.getString(2),rs.getInt(3),
					rs.getInt(4),rs.getInt(5),rs.getString(6));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}
	//도서정보 조회
	public ArrayList<BookVO> selectBook() throws SQLException {
		ArrayList<BookVO> list = new ArrayList<BookVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from bookTBL";//책제목
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		ResultSet rs = pstmt.executeQuery();
		BookVO vo = null;
		while (rs.next()) {
			vo = new BookVO(rs.getInt(1),rs.getString(2),rs.getString(3),
					rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getString(7));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}
	//대출정보 갱신
//	public ArrayList<LoanVO> updateRentalBook() {
//		ArrayList<LoanVO> list = new ArrayList<LoanVO>();
//		Connection con = ConnectionManager.getConnection();
//		String sql = "update loanTBL set *=* where *=* ";
//		PreparedStatement pstmt = con.prepareStatement(sql);
//		pstmt.setString(1, ?);
//		
//		ResultSet rs = pstmt.executeQuery();
//		LoanVO vo = null;
//		while (rs.next()) {
//			vo = new LoanVO(rs.getString(0));
//			
//			list.add(vo);
//		}
//		ConnectionManager.closeConnection(rs, pstmt, con);
//		return list;
//	}
//	//예약정보 갱신
//	public ArrayList<ReservationVO> updateReserveBook() {
//		ArrayList<ReservationVO> list = new ArrayList<ReservationVO>();
//		Connection con = ConnectionManager.getConnection();
//		String sql = "update DB명 set *=* where *=* ";
//		PreparedStatement pstmt = con.prepareStatement(sql);
//		pstmt.setString(1, ?);
//		
//		ResultSet rs = pstmt.executeQuery();
//		LibraryVO vo = null;
//		while (rs.next()) {
//			vo = new ReservationVO(rs.getString(0));
//			
//			list.add(vo);
//		}
//		ConnectionManager.closeConnection(rs, pstmt, con);
//		return list;
//	}
//	//도서정보 갱신
//	public ArrayList<BookVO> updateBook() {
//		ArrayList<BookVO> list = new ArrayList<BookVO>();
//		Connection con = ConnectionManager.getConnection();
//		String sql = "update DB명 set *=* where *=* ";
//		PreparedStatement pstmt = con.prepareStatement(sql);
//		pstmt.setString(1, ?);
//		
//		ResultSet rs = pstmt.executeQuery();
//		BookVO vo = null;
//		while (rs.next()) {
//			vo = new BookVO(rs.getString(0));
//			
//			list.add(vo);
//		}
//		ConnectionManager.closeConnection(rs, pstmt, con);
//		return list;
//	}
	
}